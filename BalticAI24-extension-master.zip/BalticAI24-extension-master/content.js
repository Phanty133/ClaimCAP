
let checks = [];

/**
 * @type {HTMLElement}
 */
let toaster;
let curCheck = null;
const TIME_END_PADDING_S = 15;

// Function to convert "HH:MM:SS,MS" to total seconds (ignoring milliseconds for simplicity)
function timeStringToSeconds(timeString) {
	const [time, ms] = timeString.split(',');
	const [hours, minutes, seconds] = time.split(':').map(Number);
	return hours * 3600 + minutes * 60 + seconds; // Convert to total seconds
}

// Function to check if the current time falls between TIME_START and TIME_END
function checkTime(currentTime, check, end_padding = 0) {
	const start = timeStringToSeconds(check.TIME_START);
	const end = timeStringToSeconds(check.TIME_END) + end_padding;
	return currentTime >= start && currentTime <= end;
}

// Function to check and update boxes based on current video time
function updateInfoBoxes(currentTime) {
	if (curCheck && !checkTime(currentTime, curCheck, TIME_END_PADDING_S)) {
		closeToaster();
		curCheck = null;
	}

	for (const check of checks) {
		if (!checkTime(currentTime, check)) continue
		if (check === curCheck) return;

		setToasterContent(check);
		openToaster();
		curCheck = check;
		break;
	}
}

// Function to get the current time of the video
// Function to get the current time of the video
function getCurrentVideoTime() {
	// Get the video element (assuming there is only one video playing)
	const bigVideoEl = document.querySelector('div[role="dialog"] video');
	const smallVideoEl = document.querySelector('video');
	let videoElement = bigVideoEl || smallVideoEl;

	if (videoElement) {
		// Get the current playback time in seconds
		var currentTimeInSeconds = videoElement.currentTime;

		// Convert the time to minutes and seconds format (MM:SS)
		var minutes = Math.floor(currentTimeInSeconds / 60);
		var seconds = Math.floor(currentTimeInSeconds % 60);

		// Format the time as MM:SS (e.g., "12:34")
		var formattedTime = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

		return {
			timeInSeconds: currentTimeInSeconds,
			formattedTime: formattedTime
		};
	} else {
		return {
			timeInSeconds: 0,
			formattedTime: "00:00"
		};
	}
}

async function initToaster() {
	const id = "CLAIMCAP-TOASTER-CONTAINER";
	const existingToaster = document.getElementById(id);

	if (existingToaster) {
		document.body.removeChild(existingToaster);
	}

	const htmlUrl = chrome.runtime.getURL('toaster.html');
	const toasterHTML = await fetch(htmlUrl).then(response => response.text());
	const container = document.createElement('div');
	container.innerHTML = toasterHTML;
	container.id = id;
	document.body.appendChild(container);
	toaster = container.querySelector(".toaster-container");
}

function addSourceEl(source) {
	// Get favicon URL
	const url = new URL(source.URL);
	const faviconUrl = `${url.origin}/favicon.ico`;

	const html = `
<a class="toaster-source" href="${url}" target="_blank">
	<div class="toaster-source-img"><img src="${faviconUrl}" alt="" onerror="this.style.display='none'"></div>
	<div class="toaster-source-link"><span">${url.hostname}</span></div>
</a>
`
	const sourcesContainer = document.querySelector(".toaster-sources-container");
	sourcesContainer.innerHTML += html;
}

function setToasterContent(claimData) {
	const claimEl = document.querySelector(".toaster-claim span");
	const verdictEl = document.querySelector(".toaster-verdict span:nth-child(2)");
	const explanationEl = document.querySelector(".toaster-explanation span");
	const timestampStartEl = document.querySelector(".toaster-timestamp span:nth-child(1)");
	const timestampEndEl = document.querySelector(".toaster-timestamp span:nth-child(3)");
	const sourcesContainer = document.querySelector(".toaster-sources-container");

	toaster.setAttribute("data-verdict", claimData.LABEL);

	claimEl.innerText = claimData.CLAIM;
	verdictEl.innerText = claimData.LABEL;
	explanationEl.innerText = claimData.EXPLANATION;
	timestampStartEl.innerText = claimData.TIME_START.split(',')[0];
	timestampEndEl.innerText = claimData.TIME_END.split(',')[0];

	sourcesContainer.innerHTML = "";
	for (const src of claimData.SOURCES) {
		addSourceEl(src);
	}
}

function openToaster() {
	toaster.setAttribute("data-open", "data-open");
}

function closeToaster() {
	if (!toaster.hasAttribute("data-open")) return;
	toaster.removeAttribute("data-open");
}

async function loadChecks(videoId) {
	chrome.runtime.sendMessage({ action: "parse-video", videoId: videoId }, async (msgResponse) => {
		if (msgResponse.error) {
			console.log("Background encountered error", msgResponse.error)
			toaster.errorToast(msgResponse.error).showToast()
			return
		}

		checks = msgResponse.checks;
	})
}

function main() {
	// Get the current URL of the page
	const currentUrl = window.location.href;
	console.log("main");

	if (currentUrl.startsWith('https://www.facebook.com/watch/live/') ||
		currentUrl.includes('/videos/')) {
		console.log("parse");

		// Initialize a variable to store the video ID
		var videoId = null;

		// Check if the URL contains the "v=" parameter (Facebook Watch URL format)
		var videoIdFromParam = currentUrl.match(/[?&]v=(\d+)/);

		if (videoIdFromParam) {
			videoId = videoIdFromParam[1]; // Extract the video ID
		}

		// If no video ID was found in the query params, check if it's in the path (Content Creator/Page Videos URL format)
		if (!videoId) {
			var videoIdFromPath = currentUrl.match(/\/videos\/(\d+)/);

			if (videoIdFromPath) {
				videoId = videoIdFromPath[1]; // Extract the video ID
			}
		}

		loadChecks(videoId);
		initToaster();

		// Update the video time every second using setInterval
		setInterval(() => {
			var videoTime = getCurrentVideoTime(); // Get the current video time
			const currentTime = videoTime.timeInSeconds;

			updateInfoBoxes(currentTime, toaster)
		}, 1000); // Update every 1000 milliseconds (1 second)
	}
}

main();

// if (window.navigation) {
// 	window.navigation.addEventListener("navigate", (event) => {
// 		main();
// 	});
// } else {
// 	window.addEventListener('locationchange', function () {
// 		main();
// 	});
// }