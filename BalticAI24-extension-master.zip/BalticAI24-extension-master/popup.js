// Wait for the popup to fully load
document.addEventListener('DOMContentLoaded', function() {
  // Get the active tab in the current window
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    // The current tab's URL
    var currentUrl = tabs[0].url;
    
    // Display the URL in the popup
    document.getElementById('currentUrl').textContent = currentUrl;
    
    // Log the current URL in the console
    console.log('Current URL:', currentUrl);
  });
});
