let testChecks = [{
    'CLAIM': 'President Trump claims that the people of Springfield, Ohio are eating the dogs, cats, and pets of the people who live there, due to the influx of immigrants.',
    'EXPLANATION': 'The claim that immigrants in Springfield, Ohio are eating the pets of the people who live there has been debunked by multiple fact-checking websites. There is no evidence to support this claim, and it is likely a baseless and dehumanizing assertion.',
    'LABEL': 'Dubious',
    'SOURCES': [{
        'NAME': 'The Dispatch',
        'URL': 'https://www.dispatch.com/story/news/2024/09/11/truth-fact-check-people-eating-dogs-springfield-ohio-trump-vance-harris-debate/75171964007/'
    }],
    'TIME_END': '00:00:05,000',
    'TIME_START': '00:00:10,000'
}];

async function setTimeoutAsync(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

async function fetchVideoChecks(videoId) {
    const API_URL = "https://server-12342736971.europe-west3.run.app/api/parse";
    const req = await fetch(API_URL, {
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": JSON.stringify({ videoId })
    });
    const data = await req.json();

    console.log(data);

    return data;
}


function handleFactCheckVideo(videoId, sendResponse) {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
        if (!tabs[0]) {
            sendResponse({ error: "No active tab" });
            return;
        }

        await setTimeoutAsync(10);

        try {
            const checks = await fetchVideoChecks(videoId)
            // const checks = testChecks;
            sendResponse({ checks });
        } catch (error) {
            sendResponse({ error: error.message });
        }
    });
    return true;
}


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "parse-video") handleFactCheckVideo(request.videoId, sendResponse);
    return true
})

